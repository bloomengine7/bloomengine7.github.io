This version of Blink! is W.I.P. and the code is rough. Please do not distribute it yet. THINK OF THE CHILDREN!

To learn how to write a basic game, check out the source code of story.js.

It would be much appreciated if you do not remove the "Powered by Blink!" link. 

If you feel like it, after you've made a game, email me and let me know.

Thanks, and enjoy!

-Simon
bloomengine.com

