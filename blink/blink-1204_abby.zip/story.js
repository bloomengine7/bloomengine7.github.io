/*

If you read the comments in this source code, you will understand the basic idea of how to write a game.

I'll try to keep the comments as simple and clear as possible. If you are not already familiar with basic programming and html coding concepts, it may be helpful to google up some tutorials on the subject.

If you're already pro, forgive me if I comment on stuff that's obvious.

Have fun making your game!
 
*/


/////////////////////////////////////
////Game Config/////////////////////
////////////////////////////////////

function config() {
	gameTitle = "A Blink Game";
	gameAuthor = "BloomEngine";
	metaContent = "{About|about} {Hints|hints}"; //goes at menu at bottom
	inventorySystem = 1; //If you don't want an inventory system in your game, set inventorySystem = 0;
	
	waitSystem = 0; //If you want a "wait" button to allow time to pass, set waitSystem = 1; If the wait system is off, it can be activated on a specific node by writing wait=1; Alternatively, if the wait system is turned on, it can be deactivated on a specific node by writing wait=0;
	
	debugMode = 0; //Right now the debugger needs php. It's hidden with css in style.css using display: none.
	
}
 
/////////////////////////////////////
////Variables////////////////////////
////////////////////////////////////

/*
Any variables that need to be stored in save games must be put into the userVariables array below. No empty spaces in the variable names! 

*/

userVariables = new Array (
	'blueRoomDark',
	'haveBall'
);

//By default, all variables in the array start off set as "0" or "false"





/*
 
node: A node is a chunk of descriptive text that the engine outputs. A situation. Or kind of like a page in a choose your own adventure book. 

By default the player starts at the "start" node.

In this demo, these are all nodes:
blueRoom
redRoom
chair
lightSwitch







/////////////////////////////////////
////Node settings reference:////////
////////////////////////////////////

root = 1; //make node a root location. When user clicks "back" they are taken back to the root location.

back = 0; turn off "back" button

wait = 0; turn off "wait" button. Only in that particular node. For turning it completely off throughout the entire game, use waitSystem = 0;

use = 1; activate "use" inventory mode when in a sub-node. For using objects to interact with other objects.

links = 0; deactivate all links in description but keep links within the event box active. Used when an event causes something to happen and you still want to show the description of room, but not have people interact with it. For example, if a timed event occurs, like the "lights go off", you 

inv = 0; hide inventory and wait button

*/





///////////////////////////////////////////////
//////////////Nodes////////////////////////////
///////////////////////////////////////////////

function nodes() { //Do not remove this line
	switch(f['node']) { //Do not remove this line

	
////////////////
case "start":
	
	root = 1; //make current node a physical or "root" location. Think of it as a room. When user clicks the "back" button they are taken back to the last root location. 
	
	//Within a node, the "d" variable holds all the text that you want the node to output. 
	d="<h2>Starting Room</h2><p>You stand in a room.</p>";
	
	//If you want to add more text then write d+="whatever new text". For example: 
	d+="<p>There is a {blue door|blueRoom}, a {red door|redRoom} and a {chair|chair}.</p>";
	
	
	
	/*
	 	  
	Note: javascript code CANNOT have line breaks within quotations.
	
	This code will not work:
	d="<h2>Starting Room</h2>
	<p>This is a demo blink game. You stand in a room.</p>";
	
	But you can add a "\" do indicate a new line. This works:
	d="<h2>Starting Room</h2>\
	<p>This is a demo blink game. You stand in a room.</p>";
	
	*/
	
	
	break;

	
///////////////
case "chair":
	//Notice this node does not have "root=1" like the starting room or the blue room, so a "back" button appears.
	d="<p>A wooden chair.</p>";
	
	break;

///////////////
case "blueRoom":
	root=1; //physical location
	
	d="<h2>Blue Room</h2>\
	<p>The floor, ceiling and walls are all blue. A door leads back to the {start room|start}</p><p>There's a {light switch|lightSwitch} on the wall.</p>";
	
	if (f['blueRoomDark']) {
		d+="<p>The room is dark.</p>"; 
		
	} else {
		d+="<p>The room is brightly lit.</p>";
		
	} 	
	
	break;

	


/////////////////
case "lightSwitch":
	d="<p>You flick the switch ";
	
	if (f['blueRoomDark']) { //if the blue room is dark, do this:
		d+="on";
		f['blueRoomDark']=0 //Turn the light off
		
	} else { 
		d+="off";
		f['blueRoomDark']=1 //Turn the light on
	}
	
	d+="</p>"
	
	break;

/*
  
a note on variables:

All variables that go into the save game need to be put into the f[] array.
  
It is best to use binary states, 1=true 0=false, or single letters ("a", "b", "c") for all game variables that need to be saved. However longer string variables can be still used keeping in mind that these variables cannot have empty spaces in them, or else the save game system breaks. Use underscore if you really need to have a longer variable name with spaces. Eg: "john_doe".
	
*/
	
/////////////

case "redRoom":
	root=1;
	d="<h2>Red Room</h2><p>The room is red. A door leads back to the {start room|start}.</p>"
	
	if (!f['haveBall']) { // For newbies: "!" means not. So this is saying "if not have ball", then print this:
		d+="<p>A {ball|takeBall} rests on the ground.</p>"
	}
	
	//This is how to make an "event" or something that displays in special formatting below the main room description. Good for displaying text that is different from the standard room description.
	if (!f['haveBall']) {
		e="<p>You feel an urge to pick up the ball</p>"; 
	}
	break;

	
	
/////////////
case "takeBall":
	d+="<p>You pick up the ball.</p>"
	f['haveBall']=1; //have ball set to true
	
	break;
	

/////////////////
case "hints":
	metaNode=1; //A meta node means that this node is for informational purposes. Time (the move counter) will not increase if the user goes to a metaNode.
	
	d="<h2>hints</h2><p>hint info.</p>";
	
	break;


		
/////////
case "about":
	metaNode=1;
	
	d+="<h2>About</h2><p>Demo info.</p>";
	
	break;


///////
case "iBall":
	d+="<p>just an ordinary ball.</p>";
	
	break;




///////In case you link to a nonexistent node, then this error message will appear
default:
	d = "Error";
	break;
	}
	
	
} //////do not remove this bracket




/////////////////////////////////////
////Inventory////////////////////////
////////////////////////////////////

function includeInv() {


	invText="<div id='objects'><ul>"; //do not erase

	//put all inventory items that can potentially be picked up into this area. Put each item into a <li></li> tag.
	
	if (f['haveBall']) {
		invText+="<li>{Ball|iBall}</li>";
	}
	




	invText+="</ul></div>";	//do not erase
}





/////////////////////////////////////////
//Object Interactions////////////////////
/////////////////////////////////////////

/*
  
this part is W.I.P. If you can figure it out, use it. I will document it better later.

*/

function interactions() {

	var end;
	
	if (f['giver']=='iPurse' && f['receiver']=='box1') {
		d+="Ppurse doesn't like it. Not a good use of purse.";
		end=1;
	}
	
	
	if (!end) {
		
		if(f['receiver']=="box1") {
		
				 
			switch(f['giver']) {
				case "iMenu":
				
					
					d+="<p>You request a sandwich. He nods and takes the menu.</p>";
					
	
					
				break;
			
				default:
				d+="<p>Doesn't go in box.</p> ";
				break;
				
			}
		} else if(f['receiver']=='cat') {
			
			switch(f['giver']) {
				case "invMouse":
					d+="It plays with the mouse";
				break;
			
				default:
				d+="It doesn't seem interested. Cats are that way sometimes. ";
				break;
				
			}
		} else if(f['receiver']=='start2') {
			switch(f['giver']) {
				default:
					d+="start 2 doesn't want it";
					//build("Start2 doesn't want it");
			}
		} else if(f['receiver']=='start3') {
			switch(f['giver']) {
				case "invApple":
					//noBack=1;
					d+="it eats the {apple|start} sdfdsf sdsd f dsfd sdfdsf sdsd f dsfdfsdfsfsdfs";
					break;
				
				case "invOrange":
					
					d+="IT doesT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangeT doesn't want orangen't want orange";
					break;
				
				default:
					d+="It doesn't want it";
					//for (i in fname) {
					//	build(fname[i]) + build(": ") + build(f[fname[i]]) + build("<br>");
					//}
			}
		
		}
		
	}	
}
/////end interactions
